@echo off
input:("Enter your victim IP addres")
if answer == %Your-ip%
then input:("ddos started")
Ddos{import time
import random
import sys

def Ddos_attack=(target):
    print(f"Initializing attack on {target}...")
    time.sleep(1)
    print("Connecting to botnet nodes... [OK]")
    time.sleep(1)
    print("Encrypting packets... [OK]")
    time.sleep(1)
    print("Launching attack...\n")

    for i in range(100):
        IP = ".".join(str(random.randint(1, 255)) for _ in range(4))
        port = random.randint(20, 65535)
        size = random.randint(500, 10000)
        sys.stdout.write(f"\rSending {size} bytes to {target}:{port} from {ip}...")
        sys.stdout.flush()
        time.sleep(0.05)

    print("\n\n Attack Complete! Target is down. ")
    print("Target wifi is Off!")

# Use it
target = input("Enter target IP or domain: ")
Ddos_attack(target)

}
pause.

exit